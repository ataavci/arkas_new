const express = require("express");
const route = express.Router();
const auth_controller = require("../controller/auth_contoller");
const validatorMiddleware = require("../middleware/validation");
const auth_middileware=require("../middleware/auth_middleware");





route.get("/", auth_controller.login_page_show);
route.post("/login",auth_middileware.openclose, auth_controller.login);


route.get("/register", auth_middileware.openclose, auth_controller.register_page_show);
route.post("/register",auth_middileware.openclose, validatorMiddleware.validateNewUser(), auth_controller.register);


route.get("/forget-password",auth_middileware.openclose, auth_controller.forget_password_page_show);
route.post("/forget-password",auth_middileware.openclose,validatorMiddleware.validateEmail(), auth_controller.forget_password);

route.get("/verify",auth_controller.verifyMail);


route.get("/logout",auth_middileware.openup,auth_controller.logout);

module.exports = route;
